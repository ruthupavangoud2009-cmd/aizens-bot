from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Optional
import discord

from src.utils.containers import KyokaContainer

if TYPE_CHECKING:
    from src.core.bot import KyokaBot

logger = logging.getLogger("Kyoka.Antinuke.Helpers")

DANGEROUS_PERMISSIONS = {
    "administrator",
    "manage_guild",
    "manage_roles",
    "manage_channels",
    "ban_members",
    "kick_members",
    "mention_everyone",
    "manage_webhooks",
}


import datetime

_processed_audit_entry_ids: dict[int, float] = {}


async def resolve_audit_perpetrator(
    guild: discord.Guild,
    action: discord.AuditLogAction,
    target_id: int | None = None,
    max_age_seconds: float = 14.0,
    retries: int = 3,
    initial_delay: float = 0.25,
) -> discord.Member | discord.User | None:
    """
    Resilient, latency-tolerant audit log resolver for antinuke triggers.
    Queries up to 8 recent entries with progressive retry backoff (0.25s, 0.5s, 0.85s) to survive Discord gateway lag.
    """
    delays = [initial_delay, 0.5, 0.85]
    for attempt in range(retries):
        await asyncio.sleep(delays[attempt] if attempt < len(delays) else 0.5)
        try:
            now = discord.utils.utcnow()
            async for entry in guild.audit_logs(action=action, limit=8):
                elapsed = (now - entry.created_at).total_seconds()
                if elapsed > max_age_seconds:
                    continue

                if target_id is not None:
                    if entry.target and getattr(entry.target, "id", None) == target_id:
                        return entry.user
                else:
                    return entry.user
        except (discord.Forbidden, discord.HTTPException) as e:
            logger.debug(f"Audit log query failed in guild {guild.id}: {e}")
            break
        except Exception as e:
            logger.warning(f"Error resolving audit perpetrator in guild {guild.id}: {e}")
            break

    return None


async def execute_punishment(
    bot: KyokaBot,
    guild: discord.Guild,
    offender: discord.Member | discord.User,
    action_name: str,
    reason: str = "Kyoka Antinuke Protocol",
) -> str:
    """
    Executes configured punishment on the unauthorized perpetrator.
    Step 1: Instantly strip all roles (neutralizes permissions in <50ms).
    Step 2: Auto-Quarantine: Apply maximum Discord communication timeout (28 days).
    Step 3: Ban or Kick according to guild configuration.
    """
    if offender.id == guild.owner_id:
        return "Owner Immune"

    if bot.user and offender.id == bot.user.id:
        return "Self Immune"

    punishment = bot.antinuke_mgr.get_punishment(guild.id)
    audit_reason = f"Kyoka Antinuke | {action_name} — {reason}"

    member: discord.Member | None = guild.get_member(offender.id)

    # 1. Neutralize permissions by stripping roles if member is in guild
    stripped_count = 0
    if member and member.roles:
        try:
            # Keep @everyone role, strip all manageable custom roles
            strip_targets = [r for r in member.roles if not r.is_default() and r < guild.me.top_role]
            if strip_targets:
                await member.remove_roles(*strip_targets, reason="Kyoka Antinuke: Instant Permission Neutralization")
                stripped_count = len(strip_targets)
                logger.info(f"Guild {guild.id}: Stripped {stripped_count} role(s) from perpetrator {offender.id}")
        except (discord.Forbidden, discord.HTTPException) as e:
            logger.warning(f"Guild {guild.id}: Could not strip roles from perpetrator {offender.id}: {e}")

    # 2. Auto-Quarantine: Apply maximum timeout (28 days) so offender is completely silenced
    if member and guild.me.guild_permissions.moderate_members:
        try:
            timeout_duration = discord.utils.utcnow() + datetime.timedelta(days=28)
            await member.timeout(timeout_duration, reason=audit_reason)
            logger.info(f"Guild {guild.id}: Applied 28-day auto-quarantine timeout to perpetrator {offender.id}")
        except Exception as e:
            logger.debug(f"Guild {guild.id}: Could not apply quarantine timeout to {offender.id}: {e}")

    # 3. Execute Ban / Kick / Quarantine
    if punishment == "ban":
        try:
            await guild.ban(offender, reason=audit_reason, delete_message_seconds=0)
            return "Banned"
        except discord.Forbidden:
            logger.warning(f"Guild {guild.id}: Missing permissions to ban offender {offender.id}")
            return "Quarantined (Role Too High to Ban)"
        except Exception as e:
            logger.error(f"Guild {guild.id}: Error banning offender {offender.id}: {e}")
            return f"Quarantined ({e})"

    elif punishment == "kick":
        if member:
            try:
                await member.kick(reason=audit_reason)
                return "Kicked"
            except discord.Forbidden:
                return "Quarantined (Role Too High to Kick)"
            except Exception as e:
                return f"Quarantined ({e})"
        else:
            return "User not in server"

    return "Quarantined (Roles Removed + Timed Out)"


async def restore_channel(guild: discord.Guild, cached_data: dict[str, Any]) -> discord.abc.GuildChannel | None:
    """Restore a deleted channel using its in-memory snapshot."""
    try:
        ch_type = cached_data.get("type")
        name = cached_data.get("name", "recovered-channel")
        category_id = cached_data.get("category_id")
        category = guild.get_channel(category_id) if category_id else None
        if not isinstance(category, discord.CategoryChannel):
            category = None

        overwrites = {}
        for target_id, (target_obj, ow) in cached_data.get("overwrites", {}).items():
            # Resolve target in guild if still present
            live_target = guild.get_role(target_id) or guild.get_member(target_id)
            if live_target:
                overwrites[live_target] = ow

        if ch_type == discord.ChannelType.text:
            return await guild.create_text_channel(
                name=name,
                category=category,
                topic=cached_data.get("topic"),
                nsfw=cached_data.get("nsfw", False),
                overwrites=overwrites,
                reason="Kyoka Antinuke: Self-Healing Channel Recreation",
            )
        elif ch_type == discord.ChannelType.voice:
            return await guild.create_voice_channel(
                name=name,
                category=category,
                overwrites=overwrites,
                reason="Kyoka Antinuke: Self-Healing Voice Channel Recreation",
            )
        elif ch_type == discord.ChannelType.category:
            return await guild.create_category(
                name=name,
                overwrites=overwrites,
                reason="Kyoka Antinuke: Self-Healing Category Recreation",
            )
    except Exception as e:
        logger.error(f"Guild {guild.id}: Failed to restore channel: {e}")
    return None


async def restore_role(guild: discord.Guild, cached_data: dict[str, Any]) -> discord.Role | None:
    """Restore a deleted role using its in-memory snapshot."""
    try:
        return await guild.create_role(
            name=cached_data.get("name", "recovered-role"),
            permissions=cached_data.get("permissions", discord.Permissions.none()),
            color=cached_data.get("color", discord.Color.default()),
            hoist=cached_data.get("hoist", False),
            mentionable=cached_data.get("mentionable", False),
            reason="Kyoka Antinuke: Self-Healing Role Recreation",
        )
    except Exception as e:
        logger.error(f"Guild {guild.id}: Failed to restore role: {e}")
    return None


async def restore_vanity(bot: KyokaBot, guild: discord.Guild, original_vanity: str) -> bool:
    """Attempt to restore the server's legitimate vanity URL code."""
    if not original_vanity:
        return False
    try:
        # Direct HTTP PATCH to restore vanity
        route = discord.http.Route("PATCH", "/guilds/{guild_id}/vanity-url", guild_id=guild.id)
        await bot.http.request(route, json={"code": original_vanity})
        logger.info(f"Guild {guild.id}: Restored vanity URL to '{original_vanity}'")
        return True
    except Exception as e:
        logger.error(f"Guild {guild.id}: Failed to restore vanity code '{original_vanity}': {e}")
        return False


async def disarm_dangerous_permissions(role: discord.Role) -> bool:
    """Disarm administrative and dangerous permissions from a compromised role."""
    try:
        perms = role.permissions
        changes = {}
        for p in DANGEROUS_PERMISSIONS:
            if getattr(perms, p, False):
                changes[p] = False

        if changes:
            await role.edit(
                permissions=discord.Permissions(**{**dict(perms), **changes}),
                reason="Kyoka Antinuke: Disarming Unauthorized Dangerous Permissions",
            )
            return True
    except Exception as e:
        logger.error(f"Guild {role.guild.id}: Failed to disarm permissions from role {role.id}: {e}")
    return False


async def dispatch_antinuke_log(
    bot: KyokaBot,
    guild: discord.Guild,
    action: str,
    offender: discord.Member | discord.User,
    punishment_result: str,
    recovery_status: str,
    extra: Optional[str] = None,
) -> None:
    """
    Format and send an incident report card to the configured log channel,
    and trigger a critical DM alert to the server owner when appropriate.
    """
    log_channel = bot.antinuke_mgr.get_log_channel(guild)
    if not log_channel:
        # Fallback to general/mod log channel if antinuke channel is unconfigured
        log_channel = bot.log_mgr.get_log_channel(guild, "mod")

    e_reg = getattr(bot, "custom_emojis", {})
    dot = e_reg.get("heart_dot", "•")
    shield = e_reg.get("icon_shield", "")
    badge_str = f"{shield} " if shield else ""

    container = KyokaContainer(accent_color=None)
    container.add_section(content=f"**{badge_str}Security Alert — {action}**")
    container.add_separator(divider=True)

    items = [
        f"> {dot} **User:** **{offender}** `「{offender.id}」`",
        f"> {dot} **Punishment:** `{punishment_result}`",
        f"> {dot} **Action Taken:** `{recovery_status}`",
    ]

    if extra:
        items.append(f"> {dot} **Details:** {extra}")

    container.add_text("\n".join(items))
    container.add_separator(divider=True)
    container.add_text(f"-# Timestamp: <t:{int(discord.utils.utcnow().timestamp())}:f>")

    # Record incident in database and in-memory history cache
    try:
        await bot.antinuke_mgr.record_incident(
            guild_id=guild.id,
            action=action,
            perpetrator_id=offender.id,
            perpetrator_tag=str(offender),
            punishment=punishment_result,
            mitigation=recovery_status,
            details=extra or "",
        )
    except Exception as e:
        logger.debug(f"Notice recording incident: {e}")

    # Send to log channel
    if log_channel:
        try:
            from src.utils.containers import send_container_response
            await send_container_response(log_channel, container)
        except Exception as e:
            logger.warning(f"Guild {guild.id}: Could not send antinuke log to channel {log_channel.id}: {e}")

    # Critical DM Alert to Server Owner
    critical_actions = ["Vanity Hijack", "Everyone Protection", "Mass Ban Attack", "Mass Channel Delete", "Mass Role Delete", "Mass Bot Raid"]
    if any(c in action for c in critical_actions):
        try:
            owner = guild.owner or await guild.fetch_member(guild.owner_id)
            if owner:
                from src.utils.containers import send_container_response
                dm_container = KyokaContainer(accent_color=None)
                dm_container.add_section(
                    content=f"**{badge_str}Security Alert in {guild.name}**\n> Unauthorized attack detected and handled."
                )
                dm_container.add_separator(divider=True)
                dm_container.add_text("\n".join(items))
                dm_container.add_separator(divider=True)
                dm_container.add_text(f"-# Timestamp: <t:{int(discord.utils.utcnow().timestamp())}:f>")
                await send_container_response(owner, dm_container)
        except Exception as e:
            logger.debug(f"Notice sending owner DM alert: {e}")

    # ------------------ AUTO-LOCKDOWN ON COORDINATED MASS RAID ------------------
    # If 3 or more rapid violations occur within 15 seconds, auto-lockdown the entire guild
    if bot.antinuke_mgr.check_rapid_raid(guild.id, threshold=3, window_seconds=15.0):
        if not bot.antinuke_mgr.is_locked_down(guild.id):
            try:
                locked_count = await bot.antinuke_mgr.emergency_lockdown(
                    guild, reason="Kyoka Antinuke: Auto-Lockdown (Raid Detected)"
                )
                logger.warning(f"Guild {guild.id}: Auto-Lockdown engaged ({locked_count} channels secured)")

                lockdown_card = KyokaContainer(accent_color=None)
                lockdown_card.add_section(
                    content=f"**{badge_str}Kyoka Lockdown**\n> Raid detected. All channels have been locked down for safety."
                )
                lockdown_card.add_separator(divider=True)
                lockdown_card.add_text(
                    f"> {dot} **Status:** `Locked Down`\n"
                    f"> {dot} **Locked Channels:** `{locked_count} Channels`\n"
                    f"> {dot} **Chat & Messages:** `Closed`\n"
                    f"> {dot} **Voice Speaking:** `Muted`\n"
                    f"> {dot} **How to open:** Use `,lockdown off` to open all channels back."
                )
                lockdown_card.add_separator(divider=True)
                lockdown_card.add_text(f"-# Kyoka Server Lockdown • <t:{int(discord.utils.utcnow().timestamp())}:f>")

                if log_channel:
                    from src.utils.containers import send_container_response
                    await send_container_response(log_channel, lockdown_card)

                owner = guild.owner or await guild.fetch_member(guild.owner_id)
                if owner:
                    from src.utils.containers import send_container_response
                    await send_container_response(owner, lockdown_card)
            except Exception as e:
                logger.error(f"Guild {guild.id}: Error during automated emergency lockdown: {e}")

