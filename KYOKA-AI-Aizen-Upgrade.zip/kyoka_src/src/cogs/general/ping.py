from __future__ import annotations

import time
import discord
from discord.ext import commands

from src.core.context import CustomContext
from src.utils.containers import KyokaContainer, send_container_response


class Ping(commands.Cog):
    """General utility and diagnostics commands."""
    category: str = "Moderation"

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.hybrid_command(
        name="ping",
        aliases=["pong", "pung", "latency"],
        description="Check Kyoka Bot's websocket, latency, and database response speed.",
    )
    async def ping(self, ctx: CustomContext) -> None:
        """Measure websocket latency, database roundtrip time, and uptime."""
        # measure DB ping
        start_db = time.perf_counter()
        await self.bot.db.fetch_one("SELECT 1;")
        db_latency = (time.perf_counter() - start_db) * 1000

        # measure Discord Websocket latency
        ws_latency = self.bot.latency * 1000

        # calculate Uptime
        now = discord.utils.utcnow()
        start = getattr(self.bot, "start_time", now)
        delta = int((now - start).total_seconds())
        hours, remainder = divmod(delta, 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_str = f"{hours}h {minutes}m {seconds}s" if hours else f"{minutes}m {seconds}s"

        shard_id = ctx.guild.shard_id if ctx.guild else 0

        e_reg = self.bot.custom_emojis
        dot = e_reg.get("heart_dot", e_reg.get("icons_rightarrow", "-"))

        container = KyokaContainer(accent_color=None)
        container.add_section(
            content=(
                f"**Kyoka Latency**\n"
                f"> Current gateway latency, database response speed, and system uptime."
            )
        )
        container.add_separator(divider=True)

        container.add_text(
            f"{dot} **Gateway:** `{ws_latency:.2f}ms` | **Database:** `{db_latency:.2f}ms`\n"
            f"{dot} **Uptime:** `{uptime_str}` | **Shard:** `#{shard_id}`"
        )
        container.add_separator(divider=True)
        container.add_text(f"-# Requested by {ctx.author.display_name}")

        await send_container_response(ctx, container)



async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Ping(bot))
