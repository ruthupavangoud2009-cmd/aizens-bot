"""
Kyoka Discord Bot - Interactive Components V2 Playlist Views
Provides interactive Dropdown Select Menu for playlist selection,
quick Play / Shuffle Play buttons, live paginated track browsing, and safe deletion.
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING, Any, Dict, List, Optional
import discord

from src.cogs.music._models import Track
from src.cogs.music._extractor import NativeExtractor
from src.utils.containers import KyokaContainer, send_container_response, edit_container_response

if TYPE_CHECKING:
    from src.core.bot import KyokaBot
    from src.cogs.music.music import Music
    from src.cogs.music._player import GuildPlayer

logger = logging.getLogger("Kyoka.Music.PlaylistViews")


def format_duration(seconds: int) -> str:
    """Format seconds into MM:SS or HH:MM:SS."""
    if not seconds:
        return "00:00"
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}h {m:02d}m {s:02d}s"
    return f"{m:02d}:{s:02d}"


def resolve_track_query(row: dict) -> str:
    """Resolve query for playlist track without stale CDN links."""
    url = (row.get("url") or "").strip()
    title = (row.get("title") or "").strip()
    author = (row.get("author") or "").strip()

    if url.startswith("http") and any(d in url for d in ("youtube.com/watch", "youtu.be/", "soundcloud.com/", "open.spotify.com/track")):
        return url

    clean_auth = author if author and author != "Official Artist" else ""
    return f"{title} {clean_auth}".strip() if clean_auth else title


async def execute_saved_playlist_playback(
    bot: KyokaBot,
    cog: Music,
    guild: discord.Guild,
    user: discord.User | discord.Member,
    channel: discord.abc.Messageable,
    pl_row: dict,
    tracks: list[dict],
    shuffle: bool = False,
    interaction: Optional[discord.Interaction] = None,
) -> None:
    """Execute playback of a saved playlist with immediate full queueing and optional shuffle."""
    if not tracks:
        c = KyokaContainer()
        c.add_section(content=f"**Playlist Notice**\n> Playlist `{pl_row['playlist_name']}` is empty.")
        if interaction:
            await send_container_response(interaction, c, ephemeral=True)
        else:
            await send_container_response(channel, c)
        return

    member = guild.get_member(user.id)
    if not member or not member.voice or not member.voice.channel:
        c = KyokaContainer()
        c.add_section(content="**Voice Error**\n> You must be connected to a voice channel to play music.")
        if interaction:
            await send_container_response(interaction, c, ephemeral=True)
        else:
            await send_container_response(channel, c)
        return

    if interaction and not interaction.response.is_done():
        await interaction.response.defer()

    player = cog.controller.get_or_create_player(guild)
    player.home_channel = channel

    try:
        await player.connect_voice(member.voice.channel)
    except Exception as e:
        c = KyokaContainer()
        c.add_section(content=f"**Connection Error**\n> Failed to connect to voice channel: `{e}`")
        if interaction:
            await send_container_response(interaction, c, ephemeral=True)
        else:
            await send_container_response(channel, c)
        return

    # Shuffle track rows if requested
    play_order = list(tracks)
    if shuffle:
        random.shuffle(play_order)

    # resolve first track immediately for instant start
    import wavelink
    first_row = play_order[0]
    first_query = resolve_track_query(first_row)
    first_track: Optional[Track] = None

    # Priority 1: High-speed Lavalink YouTube Music resolution
    try:
        results = await asyncio.wait_for(
            wavelink.Playable.search(first_query, source=wavelink.TrackSource.YouTubeMusic),
            timeout=4.0
        )
        if results and not isinstance(results, wavelink.Playlist):
            top_p = results[0]
            first_track = Track(
                title=top_p.title or first_row.get("title", "Unknown Track"),
                author=top_p.author or first_row.get("author", "Unknown Artist"),
                url=top_p.uri or first_row.get("url", ""),
                stream_url="",
                duration=int((top_p.length or 0) / 1000) or int(first_row.get("duration", 0)),
                thumbnail=top_p.artwork,
                requester=user.display_name,
                requester_id=user.id,
                query=first_query,
            )
            first_track._playable = top_p
    except Exception:
        pass

    # Priority 2: NativeExtractor (JioSaavn CDN cascade)
    if not first_track:
        try:
            first_track = await NativeExtractor.extract(first_query, requester=user.display_name)
        except Exception:
            pass

    # Priority 3: Fallback search by title + artist
    if not first_track:
        alt_q = f"{first_row.get('title', '')} {first_row.get('author', '')}".strip()
        try:
            results = await asyncio.wait_for(
                wavelink.Playable.search(alt_q, source=wavelink.TrackSource.YouTube),
                timeout=4.0
            )
            if results and not isinstance(results, wavelink.Playlist):
                top_p = results[0]
                first_track = Track(
                    title=top_p.title or first_row.get("title", "Unknown Track"),
                    author=top_p.author or first_row.get("author", "Unknown Artist"),
                    url=top_p.uri or first_row.get("url", ""),
                    stream_url="",
                    duration=int((top_p.length or 0) / 1000) or int(first_row.get("duration", 0)),
                    thumbnail=top_p.artwork,
                    requester=user.display_name,
                    requester_id=user.id,
                    query=alt_q,
                )
                first_track._playable = top_p
        except Exception:
            pass

    if not first_track:
        c = KyokaContainer()
        c.add_section(content=f"**Playback Error**\n> Failed to load first track `{first_row.get('title')}`.")
        if interaction:
            await send_container_response(interaction, c, ephemeral=True)
        else:
            await send_container_response(channel, c)
        return

    first_track.requester_id = user.id

    # append all remaining tracks to queue immediately
    was_idle = not player.is_playing and not player.is_paused
    insert_start_idx = len(player.queue)

    for row in play_order[1:]:
        q = resolve_track_query(row)
        t = Track(
            title=row.get("title") or "Unknown Track",
            author=row.get("author") or "Official Artist",
            url=row.get("url") or q,
            stream_url="",
            duration=int(row.get("duration") or 0),
            requester=user.display_name,
            requester_id=user.id,
            query=q,
        )
        player.queue.append(t)

    # Start playback
    if was_idle:
        await player.play_track(first_track)
    else:
        player.queue.insert(insert_start_idx, first_track)

    # build preview of upcoming tracks
    if was_idle:
        upcoming_items = player.queue[:6]
    else:
        upcoming_items = player.queue[insert_start_idx:insert_start_idx + 6]

    upcoming_lines = []
    for i, it in enumerate(upcoming_items, start=1):
        dur_text = it.formatted_duration
        upcoming_lines.append(f"`{i:02d}.` [{it.title}]({it.url}) `[{dur_text}]` — `{it.author}`")

    upcoming_preview = "\n".join(upcoming_lines) if upcoming_lines else "No upcoming tracks."
    remaining_count = len(play_order) - (1 if was_idle else 0) - len(upcoming_lines)

    container = KyokaContainer(accent_color=None)
    status_title = "Now Playing" if was_idle else "Queued Playlist"
    mode_str = "Shuffle" if shuffle else "Sequential"
    container.add_section(
        content=(
            f"**{status_title}: `{pl_row['playlist_name']}`**\n"
            f"> **Track:** [{first_track.title}]({first_track.url}) by `{first_track.author}`\n"
            f"> **Total Queued:** `{len(play_order)}` tracks • **Mode:** `{mode_str}`"
        )
    )

    if interaction:
        await send_container_response(interaction, container)
    else:
        await send_container_response(channel, container)


class PlaylistCreateModal(discord.ui.Modal, title="Create New Playlist"):
    """Modal to quickly name and create a new playlist."""

    name_input = discord.ui.TextInput(
        label="Playlist Name",
        placeholder="e.g. Gym, Chill, Favorites",
        max_length=50,
        required=True,
    )

    def __init__(self, hub_view: PlaylistHubView) -> None:
        super().__init__(timeout=120)
        self.hub_view = hub_view

    async def on_submit(self, interaction: discord.Interaction) -> None:
        pl_name = self.name_input.value.strip()
        if not pl_name:
            c = KyokaContainer()
            c.add_section(content="**Error**\n> Playlist name cannot be empty.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        db = self.hub_view.bot.db
        user_id = self.hub_view.author_id

        # Check if already exists
        existing = await db.fetch_one(
            "SELECT id FROM user_playlists WHERE user_id = $1 AND LOWER(playlist_name) = LOWER($2);",
            user_id,
            pl_name,
        )
        if existing:
            c = KyokaContainer()
            c.add_section(content=f"**Notice**\n> You already have a playlist named `{pl_name}`.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        # Check max 25 playlists
        count_row = await db.fetch_one(
            "SELECT COUNT(*) as cnt FROM user_playlists WHERE user_id = $1;",
            user_id,
        )
        if count_row and count_row["cnt"] >= 25:
            c = KyokaContainer()
            c.add_section(content="**Limit Reached**\n> You have reached the maximum limit of 25 playlists.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        await db.execute(
            "INSERT INTO user_playlists (user_id, playlist_name) VALUES ($1, $2);",
            user_id,
            pl_name,
        )

        # Refresh user playlists
        playlists = await db.fetch_all(
            """
            SELECT p.id, p.playlist_name, COUNT(t.id) as track_count, COALESCE(SUM(t.duration), 0) as total_duration
            FROM user_playlists p
            LEFT JOIN user_playlist_tracks t ON p.id = t.playlist_id
            WHERE p.user_id = $1
            GROUP BY p.id, p.playlist_name
            ORDER BY p.created_at DESC;
            """,
            user_id,
        )
        self.hub_view.playlists = playlists
        new_row = next((p for p in playlists if p["playlist_name"].lower() == pl_name.lower()), None)
        if new_row:
            self.hub_view.selected_playlist_id = int(new_row["id"])

        self.hub_view._rebuild_items()
        container = self.hub_view.build_container()
        await edit_container_response(interaction, container, view=self.hub_view)


class PlaylistSelectMenu(discord.ui.Select):
    """Dropdown menu listing the user's saved playlists."""

    def __init__(self, playlists: list[dict], current_selection: Optional[int] = None) -> None:
        options = []
        for pl in playlists[:25]:  # Discord allows max 25 options
            dur_str = format_duration(int(pl.get("total_duration") or 0))
            t_count = int(pl.get("track_count") or 0)
            pl_id = int(pl["id"])
            options.append(
                discord.SelectOption(
                    label=pl["playlist_name"][:100],
                    description=f"{t_count} songs • {dur_str}"[:100],
                    value=str(pl_id),
                    default=(pl_id == current_selection),
                )
            )

        super().__init__(
            placeholder="Select a playlist...",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="kyoka:playlist:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        view: PlaylistHubView = self.view  # type: ignore
        if interaction.user.id != view.author_id:
            c = KyokaContainer()
            c.add_section(content="**Access Denied**\n> This playlist hub belongs to someone else.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        selected_id = int(self.values[0])
        view.selected_playlist_id = selected_id
        await view.update_hub_card(interaction)


class PlaylistHubView(discord.ui.View):
    """Components V2 Interactive Hub View with Select Menu and Action Buttons."""

    def __init__(
        self,
        bot: KyokaBot,
        cog: Music,
        author_id: int,
        author_name: str,
        playlists: list[dict],
        prefix: str = "?",
    ) -> None:
        super().__init__(timeout=180.0)
        self.bot = bot
        self.cog = cog
        self.author_id = author_id
        self.author_name = author_name
        self.playlists = playlists
        self.prefix = prefix
        self.selected_playlist_id: Optional[int] = int(playlists[0]["id"]) if playlists else None

        self._rebuild_items()

    def _rebuild_items(self) -> None:
        """Rebuild the dropdown menu and action buttons."""
        self.clear_items()
        if self.playlists:
            self.add_item(PlaylistSelectMenu(self.playlists, self.selected_playlist_id))
        self.add_item(self.btn_play)
        self.add_item(self.btn_shuffle)
        self.add_item(self.btn_view)
        self.add_item(self.btn_new)
        self.add_item(self.btn_delete)
        self._update_button_states()

    def _get_selected_pl(self) -> Optional[dict]:
        if not self.selected_playlist_id:
            return None
        for pl in self.playlists:
            if int(pl["id"]) == self.selected_playlist_id:
                return pl
        return None

    def _update_button_states(self) -> None:
        has_sel = self.selected_playlist_id is not None and len(self.playlists) > 0
        self.btn_play.disabled = not has_sel
        self.btn_shuffle.disabled = not has_sel
        self.btn_view.disabled = not has_sel
        self.btn_delete.disabled = not has_sel

    def build_container(self) -> KyokaContainer:
        """Construct a sleek, compact Components V2 card for the Playlist Hub."""
        container = KyokaContainer(accent_color=None)

        if not self.playlists:
            container.add_section(
                content=(
                    "### Music Playlists\n"
                    "> You have no saved playlists yet.\n"
                    f"> Click **+ New** below or type `{self.prefix}playlist create <name>`."
                )
            )
            return container

        selected_pl = self._get_selected_pl()
        if selected_pl:
            dur_str = format_duration(int(selected_pl.get("total_duration") or 0))
            t_count = int(selected_pl.get("track_count") or 0)
            container.add_section(
                content=(
                    f"### Playlist: {selected_pl['playlist_name']}\n"
                    f"> **Tracks:** `{t_count}` • **Duration:** `{dur_str}`"
                )
            )
        else:
            container.add_section(
                content=(
                    f"### Saved Playlists ({len(self.playlists)})\n"
                    + "\n".join(
                        f"> • **{p['playlist_name']}** ({p['track_count']} tracks)"
                        for p in self.playlists[:6]
                    )
                )
            )
        return container

    async def update_hub_card(self, interaction: discord.Interaction) -> None:
        """Refresh the container card and dropdown selection on interaction."""
        self._update_button_states()
        for item in self.children:
            if isinstance(item, PlaylistSelectMenu):
                for opt in item.options:
                    opt.default = (opt.value == str(self.selected_playlist_id))

        container = self.build_container()
        await edit_container_response(interaction, container, view=self)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            c = KyokaContainer()
            c.add_section(content="**Access Denied**\n> This playlist hub belongs to someone else.")
            await send_container_response(interaction, c, ephemeral=True)
            return False
        return True

    @discord.ui.button(
        label="Play",
        style=discord.ButtonStyle.secondary,
        custom_id="kyoka:playlist:btn_play",
        row=1,
    )
    async def btn_play(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        selected_pl = self._get_selected_pl()
        if not selected_pl or not interaction.guild:
            c = KyokaContainer()
            c.add_section(content="**Selection Required**\n> Please select a playlist first.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        db = self.bot.db
        tracks = await db.fetch_all(
            "SELECT title, author, duration, url FROM user_playlist_tracks WHERE playlist_id = $1 ORDER BY id ASC;",
            selected_pl["id"],
        )
        await execute_saved_playlist_playback(
            self.bot,
            self.cog,
            interaction.guild,
            interaction.user,
            interaction.channel,
            selected_pl,
            tracks,
            shuffle=False,
            interaction=interaction,
        )

    @discord.ui.button(
        label="Shuffle Play",
        style=discord.ButtonStyle.secondary,
        custom_id="kyoka:playlist:btn_shuffle",
        row=1,
    )
    async def btn_shuffle(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        selected_pl = self._get_selected_pl()
        if not selected_pl or not interaction.guild:
            c = KyokaContainer()
            c.add_section(content="**Selection Required**\n> Please select a playlist first.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        db = self.bot.db
        tracks = await db.fetch_all(
            "SELECT title, author, duration, url FROM user_playlist_tracks WHERE playlist_id = $1 ORDER BY id ASC;",
            selected_pl["id"],
        )
        await execute_saved_playlist_playback(
            self.bot,
            self.cog,
            interaction.guild,
            interaction.user,
            interaction.channel,
            selected_pl,
            tracks,
            shuffle=True,
            interaction=interaction,
        )

    @discord.ui.button(
        label="View Songs",
        style=discord.ButtonStyle.secondary,
        custom_id="kyoka:playlist:btn_view",
        row=1,
    )
    async def btn_view(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        selected_pl = self._get_selected_pl()
        if not selected_pl:
            c = KyokaContainer()
            c.add_section(content="**Selection Required**\n> Please select a playlist first.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        db = self.bot.db
        tracks = await db.fetch_all(
            "SELECT id, title, author, duration, url FROM user_playlist_tracks WHERE playlist_id = $1 ORDER BY id ASC;",
            selected_pl["id"],
        )

        browse_view = PlaylistBrowseView(
            bot=self.bot,
            cog=self.cog,
            author_id=self.author_id,
            author_name=self.author_name,
            playlist=selected_pl,
            tracks=tracks,
            hub_view=self,
            prefix=self.prefix,
        )
        container = browse_view.build_container()
        await edit_container_response(interaction, container, view=browse_view)

    @discord.ui.button(
        label="+ New",
        style=discord.ButtonStyle.primary,
        custom_id="kyoka:playlist:btn_new",
        row=1,
    )
    async def btn_new(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        modal = PlaylistCreateModal(self)
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="Delete",
        style=discord.ButtonStyle.danger,
        custom_id="kyoka:playlist:btn_delete",
        row=1,
    )
    async def btn_delete(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        selected_pl = self._get_selected_pl()
        if not selected_pl:
            c = KyokaContainer()
            c.add_section(content="**Selection Required**\n> Please select a playlist first.")
            await send_container_response(interaction, c, ephemeral=True)
            return

        confirm_view = PlaylistDeleteConfirmView(
            bot=self.bot,
            cog=self.cog,
            author_id=self.author_id,
            playlist=selected_pl,
            hub_view=self,
        )
        c = KyokaContainer(accent_color=None)
        c.add_section(
            content=(
                f"**Confirm Deletion**\n"
                f"> Delete playlist **`{selected_pl['playlist_name']}`** with `{selected_pl['track_count']}` songs?"
            )
        )
        await edit_container_response(interaction, c, view=confirm_view)


class PlaylistBrowseView(discord.ui.View):
    """Live Paginated Browser for viewing all songs in a playlist with Prev / Next buttons."""

    def __init__(
        self,
        bot: KyokaBot,
        cog: Music,
        author_id: int,
        author_name: str,
        playlist: dict,
        tracks: list[dict],
        hub_view: PlaylistHubView,
        prefix: str = "?",
        per_page: int = 15,
    ) -> None:
        super().__init__(timeout=180.0)
        self.bot = bot
        self.cog = cog
        self.author_id = author_id
        self.author_name = author_name
        self.playlist = playlist
        self.tracks = tracks
        self.hub_view = hub_view
        self.prefix = prefix
        self.per_page = per_page
        self.current_page = 1
        self.total_pages = max(1, (len(tracks) + per_page - 1) // per_page)

        self._update_buttons()

    def _update_buttons(self) -> None:
        self.btn_prev.disabled = (self.current_page <= 1)
        self.btn_next.disabled = (self.current_page >= self.total_pages)

    def build_container(self) -> KyokaContainer:
        container = KyokaContainer(accent_color=None)
        display_name = self.playlist["playlist_name"]
        total_sec = sum(t["duration"] or 0 for t in self.tracks)
        total_dur = format_duration(total_sec)

        start_idx = (self.current_page - 1) * self.per_page
        page_tracks = self.tracks[start_idx : start_idx + self.per_page]

        lines = []
        for i, t in enumerate(page_tracks, start=start_idx + 1):
            dur_str = format_duration(t["duration"] or 0)
            t_url = t.get("url")
            link = f"[{t['title']}]({t_url})" if t_url and str(t_url).startswith("http") else f"`{t['title']}`"
            author = f" • {t['author']}" if t.get("author") and t.get("author") != "Official Artist" else ""
            lines.append(f"> `{i}.` {link}{author} • `{dur_str}`")

        if not lines:
            lines = ["> No songs in this playlist yet."]

        container.add_section(
            content=(
                f"### {display_name} ({len(self.tracks)} tracks • {total_dur})\n"
                + "\n".join(lines)
            )
        )
        container.add_separator(divider=True)
        container.add_text(f"-# Page {self.current_page} of {self.total_pages}")
        return container

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            c = KyokaContainer()
            c.add_section(content="**Access Denied**\n> This browser belongs to someone else.")
            await send_container_response(interaction, c, ephemeral=True)
            return False
        return True

    @discord.ui.button(
        label="Previous",
        style=discord.ButtonStyle.secondary,
        custom_id="kyoka:playlist:browse_prev",
    )
    async def btn_prev(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if self.current_page > 1:
            self.current_page -= 1
            self._update_buttons()
            container = self.build_container()
            await edit_container_response(interaction, container, view=self)
        else:
            await interaction.response.defer()

    @discord.ui.button(
        label="Next",
        style=discord.ButtonStyle.secondary,
        custom_id="kyoka:playlist:browse_next",
    )
    async def btn_next(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if self.current_page < self.total_pages:
            self.current_page += 1
            self._update_buttons()
            container = self.build_container()
            await edit_container_response(interaction, container, view=self)
        else:
            await interaction.response.defer()

    @discord.ui.button(
        label="Back to Hub",
        style=discord.ButtonStyle.primary,
        custom_id="kyoka:playlist:browse_back",
    )
    async def btn_back(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        container = self.hub_view.build_container()
        await edit_container_response(interaction, container, view=self.hub_view)


class PlaylistDeleteConfirmView(discord.ui.View):
    """Confirmation View for deleting a user playlist."""

    def __init__(
        self,
        bot: KyokaBot,
        cog: Music,
        author_id: int,
        playlist: dict,
        hub_view: PlaylistHubView,
    ) -> None:
        super().__init__(timeout=60.0)
        self.bot = bot
        self.cog = cog
        self.author_id = author_id
        self.playlist = playlist
        self.hub_view = hub_view

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            c = KyokaContainer()
            c.add_section(content="**Access Denied**\n> This prompt belongs to someone else.")
            await send_container_response(interaction, c, ephemeral=True)
            return False
        return True

    @discord.ui.button(
        label="Confirm Delete",
        style=discord.ButtonStyle.danger,
        custom_id="kyoka:playlist:confirm_delete",
    )
    async def btn_confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        db = self.bot.db
        pl_id = self.playlist["id"]
        pl_name = self.playlist["playlist_name"]

        await db.execute("DELETE FROM user_playlists WHERE id = $1;", pl_id)

        # Refresh user playlists for hub view
        updated_playlists = await db.fetch_all(
            """
            SELECT p.id, p.playlist_name, COUNT(t.id) as track_count, COALESCE(SUM(t.duration), 0) as total_duration
            FROM user_playlists p
            LEFT JOIN user_playlist_tracks t ON p.id = t.playlist_id
            WHERE p.user_id = $1
            GROUP BY p.id, p.playlist_name
            ORDER BY p.created_at DESC;
            """,
            self.author_id,
        )

        self.hub_view.playlists = updated_playlists
        self.hub_view.selected_playlist_id = int(updated_playlists[0]["id"]) if updated_playlists else None

        # Rebuild Hub View children
        self.hub_view.clear_items()
        if updated_playlists:
            self.hub_view.add_item(PlaylistSelectMenu(updated_playlists, self.hub_view.selected_playlist_id))
        self.hub_view.add_item(self.hub_view.btn_play)
        self.hub_view.add_item(self.hub_view.btn_shuffle)
        self.hub_view.add_item(self.hub_view.btn_view)
        self.hub_view.add_item(self.hub_view.btn_delete)
        self.hub_view._update_button_states()

        c = KyokaContainer(accent_color=None)
        c.add_section(
            content=(
                f"**Playlist Deleted**\n"
                f"> Playlist **`{pl_name}`** has been permanently removed.\n"
                f"> Returning you to your updated Playlist Hub."
            )
        )
        c.add_separator(divider=True)
        c.add_text("-# Powered by Kyoka Studio")
        await edit_container_response(interaction, c, view=self.hub_view)

    @discord.ui.button(
        label="Cancel",
        style=discord.ButtonStyle.secondary,
        custom_id="kyoka:playlist:cancel_delete",
    )
    async def btn_cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        c = self.hub_view.build_container()
        await edit_container_response(interaction, c, view=self.hub_view)
